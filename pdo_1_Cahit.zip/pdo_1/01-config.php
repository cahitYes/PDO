<?php
// Constantes contenant nos paramètres de connexion pour PDO
define('DB_TYPE', 'mysql');
define('DB_HOST', 'localhost');
define('DB_NAME', 'pdo_1');
define('DB_PORT', 3307);
define('DB_CHARSET', 'UTF8');
define('DB_LOGIN', 'root');
define('DB_PWD', '');
